import crypto from 'crypto'

export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex')
}
